document.addEventListener("DOMContentLoaded",() => {
    form = document.getElementById('mtForm');
    resultDiv = document.getElementById('result');
    form.addEventListener('submit', function (event) {
        event.preventDefault(); 
        name = document.getElementById('Name').value;
        Gender = document.getElementById('Gender').value;
        Interests = document.getElementById('Interests').value;
        Gender = document.getElementById('Country').value;
        resultDiv.innerHTML = `<p>Name:${Name}</p><p>Gender:${Gender} </p><p>Interests:${Interests}</p><p>Country${Country}</p>`;
    });form.addEventListener
});